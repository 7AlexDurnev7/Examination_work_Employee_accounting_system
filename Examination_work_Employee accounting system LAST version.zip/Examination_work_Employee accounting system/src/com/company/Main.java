package com.company;


import com.company.Departments.AccountingDepartment;
import com.company.Departments.SaleDepartment;
import com.company.Departments.SupplyDepartment;
import com.company.Employees.DirectorOfTheCompany;

import java.util.Collections;

public class Main {

    public static void main(String[] args) {

        // Create new employees
        Employee employee = new Employee("Petrov Ivan","11.03.1988", "male", "Manager", "Sale Department",
                "09.06.2020", 50000,
                "8-920-295-55-97");
        Employee employee1 = new Employee("Ivanov Petr","10.12.1990", "male", "Manager", "Sale Department",
                "19.10.2019", 70000,
                "8-999-99-99-99");
        Employee employee2 = new Employee("Gerdov Andrey","10.12.1980", "male", "Director", "Sale Department",
                "11.02.2020", 100000,
                "8-996-55-59-59");
        Employee employee3 = new Employee("Verbovа Irina","10.12.1967", "female", "Counter", "Accounting Department",
                "22.01.2016", 80000,
                "8-923-97-79-79");
        Employee employee4 = new Employee("Guriev Serg","10.12.1960", "male", "Manager", "Supply Department",
                "15.08.2018", 90000,
                "8-996-57-55-58");
        Employee employee5 = new Employee("Bregneva Alena","10.12.1987", "female", "Manager", "Supply Department",
                "05.03.2022", 78000,
                "8-914-67-35-17");
        Employee employee6 = new Employee("Barigina Elena","10.12.1989", "female", "Chief manager", "Supply Department",
                "08.08.2020", 110000,
                "8-916-78-15-67");
        Employee employee7 = new Employee("Barigina Elena","10.12.1989", "male", "Director", "Director of the company",
                "08.08.2020", 110000,
                "8-916-78-15-67");


        // Create list which include employees in "Sale Department"
        SaleDepartment sales = new SaleDepartment();
        sales.addEmployee(employee);
        sales.addEmployee(employee1);
        sales.addEmployee(employee2);
//        sales.showInfo();
        System.out.println(sales);
        System.out.println();

        // check method to sort
//        Collections.sort(sales.getEmployees());
//        System.out.println(sales);


        // Create list which include employees in "Accounting Department"
        AccountingDepartment account = new AccountingDepartment();
        account.addEmployee(employee3);
        System.out.println(account);
        System.out.println();

        // Create list which include employees in "Supply Department"
        SupplyDepartment supplier = new SupplyDepartment();
        supplier.addEmployee(employee4);
        supplier.addEmployee(employee5);
        supplier.addEmployee(employee6);
        System.out.println(supplier);

//        DirectorOfTheCompany dir = new DirectorOfTheCompany();
//        dir.addDirector(employee7);
//        System.out.println(dir);

    }
}
