package com.company;



import org.jetbrains.annotations.NotNull;

import java.util.LinkedList;

// Class "Employee"
public class Employee extends Person implements Comparable<Employee> {

    // Fields
    private String post; // должность
    private String department; // отдел
    private String dateOfEmployment; // дата приема на работу
    private int salary; // зарплата
    private String telephoneNumber; // номер телефона

    // Empty constructor
    public Employee() {
        super();
        this.post = "";
        this.department = "";
        this.dateOfEmployment = "";
        this.salary = 0;
        this.telephoneNumber = "";
    }

    // Getters
    public String getPost() {
        return post;
    }
    public String getDepartment() {
        return department;
    }
    public String getDateOfEmployment() {
        return dateOfEmployment;
    }
    public int getSalary() {
        return salary;
    }
    public String getTelephoneNumber() {
        return telephoneNumber;
    }

    // Constructor with parameters
    public Employee(String ID, String birthDay, String gender, String post,
                    String department, String dateOfEmployment,
                    int salary, String telephoneNumber) {
        super(ID, birthDay, gender);
        this.post = post;
        this.department = department;
        this.dateOfEmployment = dateOfEmployment;
        this.salary = salary;
        this.telephoneNumber = telephoneNumber;
    }

    // Method to compare salary
    @Override
    public int compareTo(@NotNull Employee emp) {
        return Double.compare(salary, emp.getSalary());
    }
//    public int compare(Employee empl) {
//        return Double.compare(salary, empl.getSalary());
//    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("ID: ").append(ID).append("\n")
                .append("BirthDate: ").append(birthDay).append("\n")
                .append("Gender: ").append(gender).append("\n")
                .append("Post: ").append(post).append("\n")
                .append("Department: ").append(department).append("\n")
                .append("Date of employment: ").append(dateOfEmployment).append("\n")
                .append("Salary: ").append(salary).append("\n")
                .append("Telephone number: ").append(telephoneNumber).append("\n");
        return sb.toString();
    }

} // Class "Employee" end
