package com.company.Employees;


import com.company.Employee;

import java.util.ArrayList;

// Class "DirectorOfTheCompany"
public class DirectorOfTheCompany extends Employee {

    private int bonus;
    //ArrayList<com.company.Employee> employees; // list of employees

    // Empty constructor
    public DirectorOfTheCompany() {
        super();
//        this.employees = new ArrayList<>();
    }

    public DirectorOfTheCompany(int bonus) {
        super();
        this.bonus = bonus;
//        this.employees = employees;
    }

//    public void addDirector(com.company.Employee employee) {
//        employees.add(employee);
//    }


    // Getters
//    public ArrayList<com.company.Employee> getEmployees() {
//        return employees;
//    }
    public int getBonus() {
        return bonus;
    }

    @Override
    public String toString() {
        return "DirectorOfTheCompany " +
                "bonus = " + bonus +
                "ID= " + ID + '\'' +
                "birthDay = " + birthDay + '\'' +
                "gender = " + gender + '\'' ;
    }

    //    @Override
//    public String toString() {
//        String sb = "";
//        for (Employee employee : employees) {
//            System.out.println(employee);
//        }
//        return sb + "________________________________";
//    }

} // Class "DirectorOfTheCompany" end
