package com.company;

// class "Person"
public class Person {

    // Fields
    protected String ID; // name and surname
    protected String birthDay; // birthday
    protected String gender; // male or female

    // Empty constructor
    public Person() {
        this.ID = "";
        this.birthDay = "";
        this.gender = "";
    }

    // Constructor with parameters
    public Person(String ID, String birthDay, String gender) {
        this.ID = ID;
        this.birthDay = birthDay;
        this.gender = gender;
    }

    // Getters
    public String getID() {
        return ID;
    }
    public String getBirthDay() {
        return birthDay;
    }
    public String getGender() {
        return gender;
    }

    @Override
    public String toString() {
        return "Person{" +
                "ID='" + ID + '\'' +
                ", birthDate='" + birthDay + '\'' +
                ", gender='" + gender + '\'' +
                '}';
    }
} // class "Person" end
