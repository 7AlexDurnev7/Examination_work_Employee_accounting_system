package com.company;

import java.util.ArrayList;
import java.util.List;


// Class "SaleDepartment"
public class SaleDepartment {

    ArrayList<Employee> employees; // list of employees

    // Empty constructor
    public SaleDepartment() {
        this.employees = new ArrayList<>();
    }

    // Getters
    public ArrayList<Employee> getEmployees() {
        return employees;
    }

    // Method to add new employee in "Sale Department"
    public void addEmployee(Employee employee) {
        employees.add(employee);
//        for(Employee empl : employees) {
//            employees.add(employee);
//        }
    }

//    public void showInfo() {
//        for( Employee employee : employees) {
//            System.out.println(employee);
//        }
//    }


    @Override
    public String toString() {
        String sb = "";
            for (Employee employee : employees) {
                System.out.println(employee);
            }
                return sb + "________________________________";
        }

} // Class "SaleDepartment" end
