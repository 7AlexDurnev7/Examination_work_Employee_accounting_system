package com.company.Departments;


import com.company.Employee;

import java.util.ArrayList;

// Class "DirectorOfTheCompany"
public class DirectorOfTheCompany {

    private final String post = "Director";

    ArrayList<Employee> employees; // list of employees

    // Empty constructor
    public DirectorOfTheCompany() {
        this.employees = new ArrayList<>();
    }

    public DirectorOfTheCompany(ArrayList<Employee> employees, String post) {
        this.employees = employees;
    }

    public void addDirector(Employee employee) {
        employees.add(employee);
    }

    // Getters
    public ArrayList<Employee> getEmployees() {
        return employees;
    }

    @Override
    public String toString() {
        String sb = "";
        for (Employee employee : employees) {
            System.out.println(employee);
        }
        return sb + "________________________________";
    }

} // Class "DirectorOfTheCompany" end
