package com.company;


import java.util.ArrayList;

// Class "AccountingDepartment"
public class AccountingDepartment {

    ArrayList<Employee> employees;

    // Empty constructor
    public AccountingDepartment() {
        this.employees = new ArrayList<>();
    }

    // Getters
    public ArrayList<Employee> getEmployees() {
        return employees;
    }

    // Method to add new employee in Accounting department
    public void addEmployee(Employee employee) {
        employees.add(employee);
    }

    @Override
    public String toString() {
        String sb = "";
        for (Employee employee : employees) {
            System.out.println(employee);
        }
        return sb + "________________________________";
//        return "Accounting Department " + "\n" + employees
//                + "________________________________";
    }

} // Class "AccountingDepartment" end
